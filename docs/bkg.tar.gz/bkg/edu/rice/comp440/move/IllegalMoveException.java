package edu.rice.comp440.move;

import edu.rice.comp440.*;

public class IllegalMoveException extends BackgammonException {
  public IllegalMoveException(String s) {
    super(s);
  }
} 
