package edu.rice.comp440.driver;

import edu.rice.comp440.*;

public class GameOverException extends BackgammonException {
  protected GameOverException(String s) {
    super(s);
  }
}