package edu.rice.comp440.driver;

import edu.rice.comp440.*;

public class UnrecognizedCommandException extends BackgammonException {
  protected UnrecognizedCommandException(String s) {
    super("Unrecognized command: '" + s + "'.");
  }
}