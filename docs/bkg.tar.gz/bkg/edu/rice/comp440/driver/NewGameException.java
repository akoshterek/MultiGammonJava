package edu.rice.comp440.driver;

import edu.rice.comp440.*;

public class NewGameException extends BackgammonException {
  protected NewGameException() {
    super("New game");
  }
}