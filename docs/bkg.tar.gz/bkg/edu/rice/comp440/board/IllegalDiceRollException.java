package edu.rice.comp440.board;

import edu.rice.comp440.*;

public class IllegalDiceRollException extends BackgammonException {
  protected IllegalDiceRollException(String s) {
    super(s);
  }
}
