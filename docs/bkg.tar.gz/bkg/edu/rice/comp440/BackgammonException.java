package edu.rice.comp440;

public abstract class BackgammonException extends RuntimeException {
  protected BackgammonException(String s) {
    super(s);
  }
}